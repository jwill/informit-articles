get('/') {
   render('index.html')
}
